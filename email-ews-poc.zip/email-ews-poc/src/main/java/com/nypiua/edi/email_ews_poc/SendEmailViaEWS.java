package com.nypiua.edi.email_ews_poc;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Base64;
import java.util.Properties;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.property.BodyType;
import microsoft.exchange.webservices.data.core.enumeration.property.DefaultExtendedPropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.MapiPropertyType;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.ItemId;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import microsoft.exchange.webservices.data.property.definition.ExtendedPropertyDefinition;

/**
 * Hello world!
 *
 */
public class SendEmailViaEWS 
{
	private static final Properties properties = new Properties();

	public static void main(String[] args) throws Exception {
		String subject = "Secure: Document Output"; // Encrypt the message
		String[] to = {"pmambekar@gmail.com"};
		String[] cc = {};
		String bodyText = "Hellow EWS!";
		send(subject, to, cc, bodyText);
	}
 
	
/**
 * Trigger sendEmail
 * @param subject
 * @param to
 * @param cc
 * @param bodyText
 * @throws Exception
 */
    public static void send(String subject, String[] to, String[] cc, String bodyText) throws Exception {
        doSend(subject, to, cc, bodyText, null);
    }
    
 /**
  * Send Email with Attachments
  * @param subject
  * @param to
  * @param cc
  * @param bodyText
  * @param attachmentPath
  * @throws Exception
  */
    public static void doSend(String subject, String[] to, String[] cc, String bodyText, String[] attachmentPath) throws Exception {
        ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010);
        getAppProperties();
        ExchangeCredentials credentials = new WebCredentials(properties.getProperty("email.ews.userId"), properties.getProperty("email.ews.userPassword"));
        service.setCredentials(credentials);
        try {
            service.setUrl(new URI("https://west.exch030.serverdata.net/ews/exchange.asmx")); // Make sure its TLS 1.2.. Down the line we need to protect this with DMARC
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
 
        EmailMessage msg = new EmailMessage(service);
        
        msg.setSubject(subject);
        MessageBody body = MessageBody.getMessageBodyFromText(bodyText);
        body.setBodyType(BodyType.HTML);
        msg.setBody(body);
        msg.setIsDeliveryReceiptRequested(true);
        ExtendedPropertyDefinition docRefId = new ExtendedPropertyDefinition(DefaultExtendedPropertySet.InternetHeaders, "docRefId", MapiPropertyType.String);
        msg.setExtendedProperty(docRefId, Base64.getEncoder().encode("entityRefType;entityRef#:docTypeCd;doctype".getBytes()));

        ExtendedPropertyDefinition emailPolicy = new ExtendedPropertyDefinition(DefaultExtendedPropertySet.InternetHeaders, "SECURE", MapiPropertyType.String);

        msg.setExtendedProperty(emailPolicy, "Secure");
               
        for (String s : to) {
            msg.getToRecipients().add(s);
        }
        if (cc != null) {
            for (String s : cc) {
                msg.getCcRecipients().add(s);
            }
        }
        if (attachmentPath != null && attachmentPath.length > 0) {
            for (int a = 0; a < attachmentPath.length; a++) {
                ExtendedPropertyDefinition fileAttachmentName = new ExtendedPropertyDefinition(DefaultExtendedPropertySet.InternetHeaders, "attachmentName", MapiPropertyType.String);
                msg.setExtendedProperty(fileAttachmentName, "filename.pdf");
            	msg.getAttachments().addFileAttachment(attachmentPath[a]);
            }
 
        }
                
        // Allow saving the copy in sentItems.. The foldername can be passed here to override the detault:
        msg.sendAndSaveCopy();
    }
    
    
    /**
     * Get the properties file from file-system instead of getting it from the JAR itself.
     * @throws IOException
     */
    public static void getAppProperties() throws IOException{
    	FileInputStream file;
        String path = "./email-ews-poc.properties";
        file = new FileInputStream(path);
        properties.load(file);
        file.close();       
    }    

}
